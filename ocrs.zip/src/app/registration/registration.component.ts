import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  uploadrequest:any ={}
  submitted = false;

  registerdata= new FormGroup({
    username: new FormControl(),
    password: new FormControl(),
    email: new FormControl(),
    mobile: new FormControl(),
    file: new FormControl(),
    
  })
  constructor(private route:Router, private formBuilder:FormBuilder) { }

  ngOnInit(): void {

    this.registerdata = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', Validators.required],
      mobile: ['', Validators.required],
      file: ['', Validators.required],
      
  });
  }

base: any
changeListener($event: any):void{
  this.readThis($event);
}
readThis(inputValue:any):void{
  var file: File = inputValue.target.files[0];
  var myReader: FileReader = new FileReader();
  myReader.readAsDataURL(file);
  myReader.onloadend = (e) =>{
    this.uploadrequest.data = (<string>myReader.result).split(','[1])
  }
}

get f() { return this.registerdata.controls; }

register(){
  this.submitted=true

  // stop here if form is invalid
  if (this.registerdata.invalid) {
    return;
}

  this.route.navigateByUrl('/login')  
}
home(){
  this.route.navigateByUrl('/homepage')
}
login(){
  this.route.navigateByUrl('/login')
}
}
